#include "ADD.h"

int ADD::operate(int r0, int operand) const {
  return operand + r0;
}