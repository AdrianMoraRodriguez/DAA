/**
 * @file JZERO.cc
 * @author Adrián Mora Rodríguez (alu0101465883@ull.edu.es)
 * @brief Implementación de la operación JUMP
 * @version 0.1
 * @date 2024-01-30
 * 
 */


#include "JZERO.h"

/**
 * @brief Operación de jump
 * 
 */
void JZERO::operate() const {
  try {
    isValid();
    if (data_memory_->getr0() == 0) {
      *pc_ = new_position_ - 1;
    }
  } catch (const char* e) {
    throw e;
  } catch (...) {
    throw "Error desconocido en JZERO";
  }
}

/**
 * @brief Comprueba que los datos son válidos
 * 
 */
void JZERO::isValid() const {
  if (new_position_ < 0) {
    throw "Error: Se ha intentado saltar a una posición negativa.";
  }
  if (data_reader_name_ == "error") {
    throw "Error: data_reader_name_ is error";
  }
  if (data_reader_name_ == "error") {
    throw "Error: data_reader_name_ is error";
  }
}