# Resultados de los algoritmos
Todos los tiempos están en milisegundos
| Archivo | Voraz | Tiempo Voraz | Fuerza Bruta | Tiempo Fuerza Bruta | Programación Dinámica | Tiempo Programación Dinámica |
|---------|-------|--------------|--------------|---------------------|-----------------------|-----------------------------|
| /home/usuario/DAA/p06_tsp/test/grafo18.txt | 2127.000000 | 0.000179 | 1562.000000 | 0.000771 | 1562.000000 | 0.000077 | 
| /home/usuario/DAA/p06_tsp/test/grafo17.txt | 2662.000000 | 0.000696 | 1893.000000 | 4.705440 | 1893.000000 | 0.001005 | 
| /home/usuario/DAA/p06_tsp/test/grafo20.txt | 1690.000000 | 0.000202 | 1635.000000 | 0.005244 | 1635.000000 | 0.000146 | 
| /home/usuario/DAA/p06_tsp/test/grafo9.txt | 3248.000000 | 0.003156 | 3758.000000 | EXCESIVO | 2288.000000 | 0.133344 | 
| /home/usuario/DAA/p06_tsp/test/grafo4.txt | 3022.000000 | 0.000292 | 2593.000000 | 0.044073 | 2593.000000 | 0.000226 | 
| /home/usuario/DAA/p06_tsp/test/grafo1.txt | 1955.000000 | 0.001413 | 2400.000000 | EXCESIVO | 1713.000000 | 0.011267 | 
| /home/usuario/DAA/p06_tsp/test/grafo7.txt | 3191.000000 | 0.001984 | 3796.000000 | EXCESIVO | 1708.000000 | 0.027604 | 
| /home/usuario/DAA/p06_tsp/test/grafo19.txt | 2376.000000 | 0.000678 | 1793.000000 | 5.090331 | 1793.000000 | 0.000969 | 
| /home/usuario/DAA/p06_tsp/test/grafo8.txt | 3491.000000 | 0.002037 | 3787.000000 | EXCESIVO | 1954.000000 | 0.026462 | 
| /home/usuario/DAA/p06_tsp/test/grafo13.txt | 1711.000000 | 0.000059 | 1406.000000 | 0.000039 | 1406.000000 | 0.000041 | 
| /home/usuario/DAA/p06_tsp/test/4_ciudades.txt | 85.000000 | 0.000047 | 40.000000 | 0.000036 | 55.000000 | 0.000025 | 
| /home/usuario/DAA/p06_tsp/test/grafo5.txt | 3157.000000 | 0.002418 | 4095.000000 | EXCESIVO | 2560.000000 | 0.126870 | 
| /home/usuario/DAA/p06_tsp/test/10_ciudades.txt | 285.000000 | 0.000631 | 202.000000 | 4.693046 | 202.000000 | 0.000931 | 
| /home/usuario/DAA/p06_tsp/test/grafo14.txt | 2796.000000 | 0.001146 | 2331.000000 | EXCESIVO | 2331.000000 | 0.005008 | 
| /home/usuario/DAA/p06_tsp/test/grafo12.txt | 3308.000000 | 0.005508 | 5319.000000 | EXCESIVO | 1718.000000 | 1.706966 | 
| /home/usuario/DAA/p06_tsp/test/grafo11.txt | 2309.000000 | 0.003171 | 4352.000000 | EXCESIVO | 1666.000000 | 0.308851 | 
| /home/usuario/DAA/p06_tsp/test/grafo6.txt | 1862.000000 | 0.000044 | 931.000000 | 0.000017 | 1862.000000 | 0.000019 | 
| /home/usuario/DAA/p06_tsp/test/grafo16.txt | 2688.000000 | 0.003323 | 2609.000000 | EXCESIVO | 2102.000000 | 0.057306 | 
| /home/usuario/DAA/p06_tsp/test/grafo10.txt | 2089.000000 | 0.000652 | 1683.000000 | 4.651206 | 1683.000000 | 0.000918 | 
| /home/usuario/DAA/p06_tsp/test/grafo3.txt | 2051.000000 | 0.000430 | 1565.000000 | 0.430175 | 1565.000000 | 0.000456 | 
| /home/usuario/DAA/p06_tsp/test/grafo0.txt | 2388.000000 | 0.000049 | 2068.000000 | 0.000037 | 2388.000000 | 0.000027 | 
| /home/usuario/DAA/p06_tsp/test/grafo15.txt | 1101.000000 | 0.000028 | 701.000000 | 0.000017 | 1101.000000 | 0.000018 | 
| /home/usuario/DAA/p06_tsp/test/grafo2.txt | 2149.000000 | 0.000045 | 2145.000000 | 0.000037 | 2145.000000 | 0.000026 | 
| /home/usuario/DAA/p06_tsp/test/15_ciudades.txt | 311.000000 | 0.001936 | 440.000000 | EXCESIVO | 262.000000 | 0.057491 | 
