# Resultados de los algoritmos
Todos los tiempos están en milisegundos
| Archivo | Voraz | Tiempo Voraz | Fuerza Bruta | Tiempo Fuerza Bruta | Programación Dinámica | Tiempo Programación Dinámica |
|---------|-------|--------------|--------------|---------------------|-----------------------|-----------------------------|
