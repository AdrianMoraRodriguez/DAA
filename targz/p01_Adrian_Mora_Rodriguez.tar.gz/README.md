# DAA: Práctica 1. Multiplicación de matrices
## Adrián Mora Rodríguez
Este programa realiza la multiplicación de dos matrices con dos algoritmos distintos y da el tiempo de ejecución de cada uno de ellos.
> Importante: El programa realiza tres veces cada algoritmo y muestra la media de los tiempos de ejecución.